from setuptools import setup, find_packages

setup(
    name="spidercam_simulator",
    packages=find_packages(),
    description="IHK Große Prog, Winter 2022",
    long_description="""IHK Große Prog, Winter 2022

    # Aufgabenstellung
    ToDo: Aufgabenstellung einfügen
    """,
    url="https://paddel.xyz",
    author="Patrick Gustav Blaneck",
    license="GPL-3.0-or-later",
)
